@extends('layout/base')

@section('content')
<a href="/audience" class="btn btn-secondary">Kembali</a>
<form method="post" action="{{ '/audience/'.$data->id }}">
	@csrf
	@method('PUT')
  	<div class="mb-3">
    	<label for="name" class="form-label">Nama</label>
    	<input type="text" class="form-control" name="name" id="name" value="{{ $data->name }}">
  	</div>
	  <div class="mb-3">
    	<label for="agency" class="form-label">Instansi</label>
    	<input type="text" class="form-control" name="agency" id="agency" value="{{ $data->agency }}">
  	</div>
	<div class="mb-3">
		<button type="submit" class="btn btn-primary btn-sm">Simpan</button>
	</div>
</form>
@endsection