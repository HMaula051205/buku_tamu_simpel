@extends('layout/base')

@section('content')
<form method="post" action="/audience">
	@csrf
  	<div class="mb-3">
    	<label for="agenda" class="form-label">Agenda</label>
    	<input type="text" class="form-control" name="agenda" id="agenda" value="{{ Session::get('agenda')}}">
  	</div>
	<div class="mb-3">
		<button type="submit" class="btn btn-primary btn-sm">Simpan</button>
	</div>
</form>
@endsection