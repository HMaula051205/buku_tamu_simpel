@extends('layout/base')

@section('content')
<div class="form-container">
	<div class="title">Tambah Data Tamu</div>
		<form method="post" action="/event" enctype="multipart/form-data">
			@csrf
			<div class="universal-form">
				<div class="universal-input-box">
					<span class="detail">Agenda</span>
					<input type="text" name="agenda" id="agenda" value="{{ Session::get('agenda')}}">
				</div>
			</div>
			<div class="button-submit">
					<input type="submit" value="Simpan"></input>
			</div>	
		</form>
	</div>
</div>
@endsection