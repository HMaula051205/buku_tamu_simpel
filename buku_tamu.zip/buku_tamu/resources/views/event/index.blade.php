@extends('layout/base')

@section('content')
<section>
		<div class="table-container">
            <table class="table-guest">
    <thead>
        <h2>Daftar Acara</h2>
        <tr>
            <th><a href="/event/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
            <th>No</th>
            <th>Agenda</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($data as $item)
        <tr>
            <td data-label="No">{{$loop->iteration}}</td>
            <td data-label="Agenda">{{$item->agenda}}</td>
            <td data-label="Ubah"><a class="button-edit" href='{{ url('/event/'.$item->id.'/edit') }}'>Ubah</a></td>
            <td data-label="Detail"><a class="button-detail" href='{{ url('/event/detail/'.$item->id.'/') }}'>Detail</a></td>
            <td data-label="Hapus">
                <form action="{{ '/event/'.$item->id }}" method='post'>
                    @csrf
                    @method('DELETE')
                    <button class="show-modal" type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</table>
</div>
</section>
{{ $data->links() }}
@endsection