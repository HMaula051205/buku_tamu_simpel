@extends('layout/base')

@section('content')
<a href="/event" class="button-return">Kembali</a>
<div class="form-container">
	<div class="title">Ubah Data Tamu</div>
<form method="post" action="{{ '/event/'.$data->id }}" enctype="multipart/form-data">
	@csrf
	@method('PUT')
	<div class="universal-form">
	<div class="universal-input-box">
		<span class="detail">Agenda</span>
    	<input type="text"  name="agenda" id="agenda" value="{{ $data->agenda }}">
  	</div>
</div>
<div class="button-submit">
		<input type="submit" value="Simpan">
	</div>
</form>
@endsection