@extends('layout/base')

@section('content')
<a href="/event/detaik/create" class="btn btn-primary btn-sm">Tambah data</a>
<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Instansi</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($data as $item)
        <tr>
            <td>{{$loop->iteration}}</td>
            <td>{{$item->name}}</td>
            <td>{{$item->agency}}</td>
            <td>
                <a href='{{ url('/audience/'.$item->id.'/edit') }}' class='btn btn-secondary btn-sm'>Ubah</a>
            </td>
            <td>
                <form action="{{ '/audience/'.$item->id }}" method='post'>
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
{{ $data->links() }}
@endsection