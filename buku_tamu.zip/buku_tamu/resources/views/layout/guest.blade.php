<header>
    <h2 class="logo">Logo</h2>
        <nav class="navigation">
            <a href="/guestform" class="button-guest">Form</a>
            <a href="/session" class="button-login-popup">Admin</a>
        </nav>
</header>