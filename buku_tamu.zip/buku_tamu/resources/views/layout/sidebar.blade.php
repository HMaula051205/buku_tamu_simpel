<nav class="sidebar">
    <header>
        <div class="image-text">
            <span class="image">
                <a><ion-icon name="reorder-three-sharp"></ion-icon></a>
            </span>
            <div class="sidebar-text header-text">
                <span class="title">Fungsi</span>
            </div>
        </div>
    </header> 
</nav>