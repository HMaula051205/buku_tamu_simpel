<header>
    <h2 class="logo">Logo</h2>
        <nav class="navigation">
            <a href="/guest">Buku Tamu</a>
            <a href="/agency">Instansi</a>
            <a href="/session/logout">Logout</a>
        </nav>
</header>
