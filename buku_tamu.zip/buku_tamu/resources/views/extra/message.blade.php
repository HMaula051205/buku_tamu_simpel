<!-- toast -->
@if ($errors->any())
<div class="toast" id="error-toast">
    <div class="toast-fail">
        <div class="toast-content">
            <i class="icon fail"><ion-icon name="close-sharp"></ion-icon></i>

            <div class="message">
                <span class="message-text text-status">Gagal!</span>
                @foreach ($errors->all() as $item)
                <span class="message-text text-item">{{ $item }}</span>
                @endforeach
            </div>
        </div>
        <div class="toast-progress"></div>
    </div>
</div>
@endif

@if (Session::get('success'))
<div class="toast" id="success-toast">
    <div class="toast-success">
        <div class="toast-content">
            <i class="icon success"><ion-icon name="checkmark-sharp"></ion-icon></i>

            <div class="message">
                <span class="message-text text-status">Sukses!</span>
                <span class="message-text text-item">{{ Session::get('success') }}</span>
            </div>
        </div>
        <div class="toast-progress"></div>
    </div>
</div>
@endif

<script>
    // Set timeout untuk menyembunyikan pesan error setelah beberapa waktu (misalnya, 5 detik)
    setTimeout(function() {
        var errorToast = document.getElementById('error-toast');
        if (errorToast) {
            errorToast.style.display = 'none';
        }
    }, 5000); // Timeout dalam milidetik (misalnya, 5000 untuk 5 detik)

    // Set timeout untuk menyembunyikan pesan sukses setelah beberapa waktu (misalnya, 5 detik)
    setTimeout(function() {
        var successToast = document.getElementById('success-toast');
        if (successToast) {
            successToast.style.display = 'none';
        }
    }, 5000); // Timeout dalam milidetik (misalnya, 5000 untuk 5 detik)
</script>

<!-- modal-box -->

{{-- <div class="modal">
    <div class="modal-box">
        <i><ion-icon name="alert-circle-sharp"></ion-icon></i>
        <h3>Apakah kamu yakin ingin menghapus data ini?</h3>
        <div class="button-modal">
            <button class="button-cancel">Batal</button>
            <button>Ya</button>
        </div>
    </div>
</div> --}}
