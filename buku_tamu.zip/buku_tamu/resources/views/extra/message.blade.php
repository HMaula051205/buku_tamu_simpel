<!-- toast -->
@if ($errors->any())
<div class="toast" id="error-toast">
    <div class="toast-fail">
        <div class="toast-content">
            <i class="icon fail"><ion-icon name="close-sharp"></ion-icon></i>

            <div class="message">
                <span class="message-text text-status">Gagal!</span>
                @foreach ($errors->all() as $item)
                <span class="message-text text-item">{{ $item }}</span>
                @endforeach
            </div>
        </div>
        <div class="toast-progress"></div>
    </div>
</div>
@endif

@if (Session::get('success'))
<div class="toast" id="success-toast">
    <div class="toast-success">
        <div class="toast-content">
            <i class="icon success"><ion-icon name="checkmark-sharp"></ion-icon></i>

            <div class="message">
                <span class="message-text text-status">Sukses!</span>
                <span class="message-text text-item">{{ Session::get('success') }}</span>
            </div>
        </div>
        <div class="toast-progress"></div>
    </div>
</div>
@endif

<script>
    setTimeout(function() {
        var errorToast = document.getElementById('error-toast');
        if (errorToast) {
            errorToast.style.display = 'none';
        }
    }, 5000);
    
    setTimeout(function() {
        var successToast = document.getElementById('success-toast');
        if (successToast) {
            successToast.style.display = 'none';
        }
    }, 5000);
</script>
