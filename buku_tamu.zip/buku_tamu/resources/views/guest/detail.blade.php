@extends('layout/base')

@section('content')
<div class="form-container">
    <div class="universal-form">
    <a href="/guest" class="button-return">Kembali</a>
    <h1>{{$data->name}}</h1>
    <p>
        <b>No Id</b> {{$data->id}}
    </p>
    <p>
        <b>Instansi</b> {{$data->agency}}
    </p>
    <p>
        <b>Agenda</b> {{$data->agenda}}
    </p>
</div>
</div>
@endsection