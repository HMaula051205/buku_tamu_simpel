@extends('layout/base')

@section('content')

<section>
    <div class="table-container">
        <form action="{{ url('/guest') }}" method="GET">
            <input type="text" name="query" placeholder="Cari data" value="{{ request('query') }}">
            <button type="submit">Cari</button>
        </form>
        <div class="sort-container">
            <label for="sort">Urutkan berdasarkan:</label>
            <select id="sort">
                <option value="date_asc">Tanggal (Terbaru ke Terlama)</option>
                <option value="date_desc">Tanggal (Terlama ke Terbaru)</option>
                <option value="name_asc">Nama (A-Z)</option>
                <option value="name_desc">Nama (Z-A)</option>
            </select>
            <button id="sort-button">Urutkan</button>
        </div>
        <table class="table-guest">
            <thead>
                <h2>Buku Tamu</h2>
                <tr>
                    <th><a href="/guest/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Nama</th>
                    <th>Instansi</th>
                    <th>Agenda</th>
                    <th>Keterangan</th>
                    <th colspan="2">Action</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($data as $item)
            <tr>
                <td data-label="Foto">
                @if ($item->picture)
                <img style="max-width:100px;" src="{{ url ('picture').'/'.$item->picture }}"/>
                @endif
                </td>
            <td data-label="No">{{$loop->iteration}}</td>
            <td data-label="Tanggal">{{$item->date}}</td>
            <td data-label="Nama">{{$item->name}}</td>
            <td data-label="Instansi">{{$item->agency->agency_name}}</td>
            <td data-label="Agenda">{{$item->agenda}}</td>
            <td data-label="Keterangan">{{$item->information}}</td>
            <td data-label="Ubah"><a class="button-edit" href='{{ url('/guest/'.$item->id.'/edit') }}'><ion-icon name="pencil-sharp"></ion-icon></a></td>
            <td data-label="Hapus"><button class="show-modal" type="button" data-id="{{ $item->id }}"><ion-icon name="trash-sharp"></ion-icon></button></td>
            </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</section>
@foreach ($data as $item)
<form action="{{ '/guest/'.$item->id }}" method='post'>
        @include('extra/modal', ['id' => $item->id])
        <input type="hidden" name="_method" value="DELETE">
</form>
@endforeach
{{ $data->links() }}
@endsection
