@extends('layout/base')

@section('content')
@section('title', 'Edit Data Tamu')
<a href="/guest" class="button-return">Kembali</a>
<div class="form-container">
	<div class="title">Ubah Data Tamu</div>
<form method="post" action="{{ '/guest/'.$data->id }}" enctype="multipart/form-data">
	@csrf
	@method('PUT')
	<div class="universal-form">
	<div class="universal-input-box">
		<span class="detail">Tanggal</span>
    	<input type="date"  name="date" id="date" value="{{ $data->date }}">
  	</div>
  	<div class="universal-input-box">
	  	<span class="detail">Nama</label>
    	<input type="text" name="name" id="name" value="{{ $data->name }}">
  	</div>
  	<div class="universal-input-box">
		<span class="detail">Instansi</span>
		<select id="agency" name="agency_id">
			<option disabled selected>Pilih Instansi</option>
        @foreach ($agency as $item)
            <option value="{{$item->id}}" {{$item->id == $data->agency_id ? 'selected' : ''}}>{{$item->agency_name}}</option>
        @endforeach
		</select>
	</div>
	<div class="universal-input-box">
		<span class="detail">Agenda</span>
    	<input type="text" name="agenda" id="agenda" value="{{ $data->agenda }}">
	</div>
	<div class="universal-input-box">
		<span class="detail">Keterangan</span>
    	<input type="text" name="information" value="{{ $data->information }}">
	</div>
	@if ($data->picture)
		<div class="universal-input-box">
			<span><label for="picture">Gambar Saat ini :</label></span>
			<img style="max-width:100px;max-height=100px;padding-top" src="{{ url('picture').'/'.$data->picture}}">
		</div>
	@endif
	<div class="universal-input-box">
		<span class="detail">Foto</label>
    	<input type="file" name="picture" id="picture" value="{{ $data->picture }}">
		@if($data->picture)
	<input type="hidden" name="old_picture" value="{{ $data->picture }}">
@endif
	</div>
</div>
<div class="button-submit">
		<input type="submit" value="Simpan">
	</div>
</form>
@endsection