@extends('layout/base')

@section('content')
<section>
		<div class="table-container">
            <form action="{{ url('/agency') }}" method="GET">
                <input type="text" name="query" placeholder="Cari instansi" value="{{ request('query') }}">
                <button type="submit">Cari</button>
            </form>
            <table class="table-guest">
                <div class="sort-container">
                    <label for="sort">Urutkan berdasarkan:</label>
                    <select id="sort">
                        <option value="agency_name_asc">Nama Instansi (A-Z)</option>
                        <option value="agency_name_desc">Nama Instansi (Z-A)</option>
                    </select>
                    <button id="sort-button">Urutkan</button>
                </div>
    <thead>
        <h2>Daftar Instansi</h2>
        <tr>
            <th><a href="/agency/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
            <th>No</th>
            <th>Nama Instansi</th>
            <th>Logo</th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($data as $item)
        <tr>
            <td></td>
            <td data-label="No">{{$loop->iteration}}</td>
            <td data-label="Nama Instansi">{{$item->agency_name}}</td>
            <td data-label="Logo">
                @if ($item->picture)
                    <img style="max-width:60px; max-height:60px" src="{{ url ('picture').'/'.$item->picture }}"/>
                @endif
            <td data-label="Ubah"><a class="button-edit" href='{{ url('/agency/'.$item->id.'/edit') }}'><ion-icon name="pencil-sharp"></ion-icon></a></td>
            <td data-label="Hapus"><button class="show-modal" type="button" data-id="{{ $item->id }}"><ion-icon name="trash-sharp"></button></td>
        </tr>
        @endforeach
    </tbody>
    </table>
</div>
</section>
@foreach ($data as $item)
<form action="{{ '/agency/'.$item->id }}" method='post'>
    @include('extra/modal', ['id' => $item->id])
        <input type="hidden" name="_method" value="DELETE">
</form>
</div>
@endforeach
{{ $data->links() }}
@endsection