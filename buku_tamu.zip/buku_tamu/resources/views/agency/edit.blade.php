@extends('layout/base')

@section('content')
@section('title', 'Ubah Data Instansi')
<a href="/guest" class="button-return">Kembali</a>
<div class="form-container">
	<div class="title">Ubah Data Instansi</div>
<form method="post" action="{{ '/agency/'.$data->id }}" enctype="multipart/form-data">
	@csrf
	@method('PUT')
	<div class="universal-form">
  	<div class="universal-input-box">
	  	<span class="detail">Nama Instansi</label>
    	<input type="text" name="agency_name" id="agency_name" value="{{ $data->agency_name }}">
  	</div>
  	<div class="universal-input-box">
	  	<span class="detail">Logo</span>
		<input type="file" name="picture" id="picture" value="{{ $data->picture }}">
	@if($data->picture)
	<input type="hidden" name="old_picture" value="{{ $data->picture }}">
@endif
	</div>
	@if ($data->picture)
		<div class="universal-input-box">
			<span>Gambar saat ini: </span>
			<br>
			<img style="max-width:100px;max-height=100px" src="{{ url('picture').'/'.$data->picture}}">
		</div>
	@endif
</div>
<div class="button-submit">
		<input type="submit" value="Simpan">
	</div>
</form>
</div>
{{-- <script>
	function showFileName(input) {
		var label = document.getElementById('picture_label');
		if (input.files && input.files[0]) {
			label.innerHTML = input.files[0].name;
		} else {
			label.innerHTML = 'Pilih gambar...';
		}
	}
</script> --}}
@endsection