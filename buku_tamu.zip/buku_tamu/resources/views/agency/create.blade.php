@extends('layout/base')

@section('content')
@section('title', 'Tambah Data Instansi')
<div class="form-container">
	<div class="title">Tambah Data Instansi</div>
		<form method="post" action="/agency" enctype="multipart/form-data">
			@csrf
			<div class="universal-form">
				<div class="universal-input-box">
					<span class="detail">Nama Instansi</span>
					<input type="text" name="agency_name" id="agency_name" value="{{ old('agency_name') }}">
				</div>
				<div class="universal-input-box">
					<span class="detail">Logo</span>
					<input type="file" name="picture" id="picture" value="{{ Session::get('picture')}}">
				</div>
			</div>
			<div class="button-submit">
				<input type="submit" value="Simpan">
			</div>	
		</form>
	</div>
</div>
@endsection