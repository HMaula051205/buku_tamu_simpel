<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AgencySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('agencies')->insert([
            'agency_name'=>'Court of Fontaine',
            'picture'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('agencies')->insert([
            'agency_name'=>'Astral Express',
            'picture'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('agencies')->insert([
            'agency_name'=>'Adepti',
            'picture'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('agencies')->insert([
            'agency_name'=>'Interastral Peace Corporation',
            'picture'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);
    }
}
