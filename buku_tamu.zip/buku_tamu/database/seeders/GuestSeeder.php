<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GuestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('guests')->insert([
            'name'=>'Harits Maula',
            'agency'=>'SMK ICB CT',
            'agenda'=>'Praktik Ujikom',
            'information'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'Tenz',
            'agency'=>'Sentinel',
            'agenda'=>'VCT Champion',
            'information'=>'[REDACTED]',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'El Gemoy',
            'agency'=>'PAN',
            'agenda'=>'Pelantikan ke-Presidenan',
            'information'=>'Sakit hati aku wak',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'Lewis Hamilton',
            'agency'=>'Petronas AMG',
            'agenda'=>'Transfer to Ferrari',
            'information'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'Xianyun',
            'agency'=>'Adepti',
            'agenda'=>'Lantern Rite',
            'information'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'Jesus',
            'agency'=>'[Confidential Information]',
            'agenda'=>'Second Coming',
            'information'=>'[Prohibited]',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'Carlos Sainz',
            'agency'=>'Scuderia Ferrari',
            'agenda'=>'dsdsadsd',
            'information'=>'dsasdsad',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'Rozaan Muhammad Adha',
            'agency'=>'SMK ICB CT',
            'agenda'=>'Praktik Ujikom',
            'information'=>'[Prohibited]',
            'created_at'=>date('Y-m-d H:i:s')
        ]);

        DB::table('guests')->insert([
            'name'=>'Jordan Barrett',
            'agency'=>'dasd',
            'agenda'=>'Dior 2023',
            'information'=>'',
            'created_at'=>date('Y-m-d H:i:s')
        ]);
    }
}
