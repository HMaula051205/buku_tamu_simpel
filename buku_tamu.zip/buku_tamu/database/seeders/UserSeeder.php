<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'Joon He "Jett"',
            'email' => 'jett051205@gmail.com',
            'password' => Hash::make('jett/767'),
            'created_at' => date('Y-m-d h:i:s')
        ]);

        $admin = User::create([
            'name' => 'Admin role',
            'email' => 'admin@role.test',
            'password' => bcrypt('12345678'),
            'created_at' => date('Y-m-d h:i:s')
        ]);

        $admin->assignRole('admin');

        $user = User::create([
            'name' => 'User role',
            'email' => 'user@role.test',
            'password' => bcrypt('12345678'),
            'created_at' => date('Y-m-d h:i:s')
        ]);

        $user->assignRole('user');
    }
}
