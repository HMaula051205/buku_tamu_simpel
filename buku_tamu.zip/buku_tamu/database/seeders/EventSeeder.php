<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('events')->insert([
            'agenda'=>'Lantern Rite',
        ]);

        DB::table('events')->insert([
            'agenda'=>'Holy Grail War',
        ]);

        DB::table('events')->insert([
            'agenda'=>'Second Coming of Jesus',
        ]);
    }
}
