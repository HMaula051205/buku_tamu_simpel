<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GuestController;
use App\Http\Controllers\AgencyController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\EventDetailController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\GuestFormController;
use App\Http\Controllers\FormBuilderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
  return view('guestform');
})->middleware('isGuest');

Route::get('/form', function () {
  return view('form');
});

Route::get('/session', function () {
  return view('session');
});

Route::resource('guest', GuestController::class)->middleware('isLogin');
Route::resource('agency', AgencyController::class)->middleware('isLogin');
Route::resource('event', EventController::class)->middleware('isLogin');
Route::resource('event/detail', EventDetailController::class)->middleware('isLogin');
Route::resource('guestform', GuestFormController::class);
Route::resource('formbuilder', FormBuilderController::class)->middleware('isLogin');
Route::resource('formbuilder/detail', FormBuilderController::class)->middleware('isLogin');
// Route::get('formbuilder', [FormBuilderController::class, 'index'])->middleware('isLogin');
// Route::get('formbuilder/create', [FormBuilderController::class, 'create'])->middleware('isLogin');
// Route::post('save-form-builder', [FormBuilderController::class, 'create'])->middleware('isLogin');
// Route::delete('form-delete/{id}', [FormBuilderController::class, 'destroy'])->middleware('isLogin'); 

Route::get('/session', [SessionController::class, 'index'])->middleware('isGuest');
Route::get('/session/register', [SessionController::class, 'register']);
Route::post('/session/create', [SessionController::class, 'create']);
Route::post('/session/login', [SessionController::class, 'login'])->middleware('isGuest');
Route::get('/session/logout', [SessionController::class, 'logout']);

  