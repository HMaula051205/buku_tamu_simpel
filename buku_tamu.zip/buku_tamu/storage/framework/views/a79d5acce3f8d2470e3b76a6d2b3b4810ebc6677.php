
<?php $__env->startSection('title', 'Tamu'); ?>

<?php $__env->startSection('content'); ?>

<h1> Ini Adalah Halaman Data Tamu </h1>

<table class="table table-striped">
    <tr>

    <th>No</th>
    <th>Hari/Tanggal</th>
    <th>Nama</th>
    <th>Instansi</th>
    <th>Agenda</th>
    <th>Keterangan</th>

    </tr>
    <?php $__currentLoopData = $tamuList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($data->haritanggal); ?></td>
        <td><?php echo e($data->nama); ?></td>
        <td><?php echo e($data->instansi); ?></td>
        <td><?php echo e($data->agenda); ?></td>
        <td><?php echo e($data->keterangan); ?></td>
     </tr>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <a href="tamu-add" title="Tambah data"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i>Tambah data baru</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/tamu.blade.php ENDPATH**/ ?>