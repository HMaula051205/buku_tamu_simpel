

<?php $__env->startSection('content'); ?>
<section>
		<div class="table-container">
            <form action="<?php echo e(url('/agency')); ?>" method="GET">
                <input type="text" name="query" placeholder="Cari instansi" value="<?php echo e(request('query')); ?>">
                <button type="submit">Cari</button>
            </form>
            <table class="table-guest">
                <div class="sort-container">
                    <label for="sort">Urutkan berdasarkan:</label>
                    <select id="sort">
                        <option value="agency_name_asc">Nama Instansi (A-Z)</option>
                        <option value="agency_name_desc">Nama Instansi (Z-A)</option>
                        <!-- Tambahkan opsi untuk kriteria pengurutan lain jika diperlukan -->
                    </select>
                    <button id="sort-button">Urutkan</button>
                </div>
    <thead>
        <h2>Daftar Instansi</h2>
        <tr>
            <th><a href="/agency/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
            <th>No</th>
            <th>Nama Instansi</th>
            <th>Logo</th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td></td>
            <td data-label="No"><?php echo e($loop->iteration); ?></td>
            <td data-label="Nama Instansi"><?php echo e($item->agency_name); ?></td>
            <td data-label="Logo">
                <?php if($item->picture): ?>
                    <img style="max-width:60px; max-height:60px" src="<?php echo e(url ('picture').'/'.$item->picture); ?>"/>
                <?php endif; ?>
            <td data-label="Ubah"><a class="button-edit" href='<?php echo e(url('/agency/'.$item->id.'/edit')); ?>'><ion-icon name="pencil-sharp"></ion-icon></a></td>
            <td data-label="Hapus"><button class="show-modal" type="button" data-id="<?php echo e($item->id); ?>"><ion-icon name="trash-sharp"></button></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</div>
</section>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e('/agency/'.$item->id); ?>" method='post'>
    <?php echo $__env->make('extra/modal', ['id' => $item->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="hidden" name="_method" value="DELETE">
</form>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/agency/index.blade.php ENDPATH**/ ?>