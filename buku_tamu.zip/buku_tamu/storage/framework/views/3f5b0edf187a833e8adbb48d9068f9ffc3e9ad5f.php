

<?php $__env->startSection('content'); ?>
<a href="/guest" class="button-return">Kembali</a>
<div class="form-container">
	<div class="title">Ubah Data Instansi</div>
<form method="post" action="<?php echo e('/agency/'.$data->id); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PUT'); ?>
	<div class="universal-form">
  	<div class="universal-input-box">
	  	<span class="detail">Nama Instansi</label>
    	<input type="text" name="agency_name" id="agency_name" value="<?php echo e($data->agency_name); ?>">
  	</div>
  	<div class="universal-input-box">
	  	<span class="detail">Logo</span>
		<input type="file" name="picture" id="picture" value="<?php echo e($data->picture); ?>">
	<?php if($data->picture): ?>
	<input type="hidden" name="old_picture" value="<?php echo e($data->picture); ?>">
<?php endif; ?>
	</div>
	<?php if($data->picture): ?>
		<div class="universal-input-box">
			<span>Gambar saat ini: </span>
			<br>
			<img style="max-width:100px;max-height=100px" src="<?php echo e(url('picture').'/'.$data->picture); ?>">
		</div>
	<?php endif; ?>
</div>
<div class="button-submit">
		<input type="submit" value="Simpan">
	</div>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/agency/edit.blade.php ENDPATH**/ ?>