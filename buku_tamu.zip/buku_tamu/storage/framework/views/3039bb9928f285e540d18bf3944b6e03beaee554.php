

<?php $__env->startSection('title', 'Student'); ?>


<?php $__env->startSection('content'); ?>
    <h1> Ini Adalah Halaman Murid By Harits</h1>
    <h3> Data Sekolah </h3>

    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Gender</th>
                <th>NIS</th>
                <th>Class</th>
            </tr>
        </thead>
        <tbody>
             <?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->gender); ?></td>
                <td><?php echo e($data->nis); ?></td>
                <td><?php echo e($data->class['name']); ?></td>
             </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara9_master\resources\views/student.blade.php ENDPATH**/ ?>