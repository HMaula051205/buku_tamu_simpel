
<?php $__env->startSection('title', 'Class'); ?>

<?php $__env->startSection('content'); ?>

<h1> Ini Adalah Halaman Class </h1>

<table class="table table-striped">
    <tr>

    <th>    No   </th>
    <th>   Hari/Tanggal   </th>
    <th>               </th>

    </tr>
    <?php $__currentLoopData = $classroomList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>

     <th>    <?php echo e($loop->iteration); ?>    </th> 
     <th> <li> <?php echo e($data->name); ?> </li> </th> 
    

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/classroom.blade.php ENDPATH**/ ?>