

<?php $__env->startSection('content'); ?>
<div class="form-container">
    <div class="universal-form">
    <a href="/guest" class="button-return">Kembali</a>
    <h1><?php echo e($data->name); ?></h1>
    <p>
        <b>No Id</b> <?php echo e($data->id); ?>

    </p>
    <p>
        <b>Instansi</b> <?php echo e($data->agency); ?>

    </p>
    <p>
        <b>Agenda</b> <?php echo e($data->agenda); ?>

    </p>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/guest/detail.blade.php ENDPATH**/ ?>