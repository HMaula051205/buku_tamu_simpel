

<?php $__env->startSection('title', 'Student'); ?>


<?php $__env->startSection('content'); ?>
<h1> Ini Adalah Halaman Murid By Opiq</h1>
<h3> Data Sekolah </h3>

<table class="table table-striped">
<tr>

<th> Nama   </th>
<th> Gender </th>   
<th> Nis    </th>
<th> Class  </th>

</tr>

<?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>

<th> <li> <?php echo e($p->name); ?>    </li>  </th>
<th> <li> <?php echo e($p->gender); ?>  </li>  </th>
<th> <li> <?php echo e($p->nis); ?>     </li>  </th>
<th> <li> <?php echo e($p->class_id); ?></li>  </th>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\lara9_master\resources\views/student.blade.php ENDPATH**/ ?>