

<?php $__env->startSection('content'); ?>
<a href="/guest" class="button-return">Kembali</a>
<div class="form-container">
	<div class="title">Ubah Data Tamu</div>
<form method="post" action="<?php echo e('/guest/'.$data->id); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PUT'); ?>
	<div class="universal-form">
	<div class="universal-input-box">
		<span class="detail">Tanggal</span>
    	<input type="date"  name="date" id="date" value="<?php echo e($data->date); ?>">
  	</div>
  	<div class="universal-input-box">
	  	<span class="detail">Nama</label>
    	<input type="text" name="name" id="name" value="<?php echo e($data->name); ?>">
  	</div>
  	<div class="universal-input-box">
		<span class="detail">Instansi</span>
		<select id="agency" name="agency_id">
			<option disabled selected>Pilih Instansi</option>
        <?php $__currentLoopData = $agency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $data->agency_id ? 'selected' : ''); ?>><?php echo e($item->agency_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
	<div class="universal-input-box">
		<span class="detail">Agenda</span>
    	<input type="text" name="agenda" id="agenda" value="<?php echo e($data->agenda); ?>">
	</div>
	<div class="universal-input-box">
		<span class="detail">Keterangan</span>
    	<input type="text" name="information" value="<?php echo e($data->information); ?>">
	</div>
	<?php if($data->picture): ?>
		<div class="universal-input-box">
			<span><label for="picture">Gambar Saat ini :</label></span>
			<img style="max-width:100px;max-height=100px;padding-top" src="<?php echo e(url('picture').'/'.$data->picture); ?>">
		</div>
	<?php endif; ?>
	<div class="universal-input-box">
		<span class="detail">Foto</label>
    	<input type="file" name="picture" id="picture" value="<?php echo e($data->picture); ?>">
		<?php if($data->picture): ?>
	<input type="hidden" name="old_picture" value="<?php echo e($data->picture); ?>">
<?php endif; ?>
	</div>
</div>
<div class="button-submit">
		<input type="submit" value="Simpan">
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/guest/edit.blade.php ENDPATH**/ ?>