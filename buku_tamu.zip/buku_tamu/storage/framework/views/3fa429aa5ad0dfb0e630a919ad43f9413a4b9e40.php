

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Tambah Data Tamu'); ?>
<div class="form-container">
	<div class="title">Tambah Data Tamu</div>
		<form method="post" action="/guest" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="universal-form">
				<div class="universal-input-box">
					<span class="detail">Tanggal</span>
					<input type="date" name="date" id="date" value="<?php echo e(Session::get('date')); ?>">
				</div>
				<div class="universal-input-box">
					<span class="detail">Nama</label>
					<input type="text" placeholder="Masukkan nama tamu" name="name" id="name" value="<?php echo e(Session::get('name')); ?>">
				</div>
				<div class="universal-input-box">
					<span class="detail">Instansi</span>
					<select id="agency_id" name="agency_id">
						<option selected disabled>Pilih Instansi</option>
						<?php $__currentLoopData = $agency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($item->id); ?>"><?php echo e($item->agency_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="universal-input-box">
					<span class="detail">Agenda</span>
					<input type="text" placeholder="Masukkan judul agenda" name="agenda" id="agenda" value="<?php echo e(Session::get('agenda')); ?>">
				</div>
				<div class="universal-input-box">
					<span class="detail">Keterangan</span>
					<input type="text" placeholder="Keterangan (dapat dikosongkan)" name="information" id="information" value="<?php echo e(old('information')); ?>">
				</div>
				<div class="universal-input-box">
					<span class="detail">Foto</label>
					<input type="file" placeholder="Masukkan gambar" name="picture" id="picture" value="<?php echo e(Session::get('picture')); ?>">
				</div>
			</div>
			<div class="button-submit">
					<input type="submit" value="Simpan"></input>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/guest/create.blade.php ENDPATH**/ ?>