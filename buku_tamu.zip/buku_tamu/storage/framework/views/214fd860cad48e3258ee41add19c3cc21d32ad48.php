

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <label for="name">Nama</label>
        <input type="text" name="name" id="name">
        <div id="fb-editor"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script>
<script src="<?php echo e(URL::asset('assets/form-builder/form-builder.min.js')); ?>"></script>
<script>
    jQuery(function($) {
        $(document.getElementById('fb-editor')).formBuilder({
            onSave: function(evt, formData) {
                console.log(formData);
                saveForm(formData);
            },
        });
    });

    function saveForm(form) {
        $.ajax({
            type: 'post',
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            },
            url: 'https://stacktips.rf.gd/save-form-builder',
            data: {
                'form': form,
                'name': $("#name").val(),
                "_token": "KdWrYRaYZEAAoJ8BtEBLkPJnUfvOloS9gjUqV9sD",
            },
            success: function(data) {
                location.href = "/form-builder";
                console.log(data);
            }
        });
    }
</script>

<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/form-builder/create.blade.php ENDPATH**/ ?>