

<?php $__env->startSection('title', 'Inventory' | 'Add New'); ?>

<?php $__env->startSection('content'); ?>

<div class="mt-5 col-6 m-auto">
    <h1 style="color: teal">Tambah Barang</h1>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<form action="inventory" method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="nama_barang">Nama Barang</label>
        <input type="text" class= " form-control  " name="nama_barang" id="nama_barang">
    </div>
    <div class="mb-3">
        <label for="jumlah">Jumlah</label>
        <input type="text" class="form-control" name="jumlah" id="jumlah">
    </div>
    <div class="mb-3">
        <label for="kondisi">Kondisi</label>
        <input type="text" class="form-control" name="kondisi" id="kondisi">
    </div>
    <div class="mb-3">
            <button class="btn btn-success" type="submit">simpan</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara9_master\resources\views/inventory_add.blade.php ENDPATH**/ ?>