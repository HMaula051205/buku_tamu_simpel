

<?php $__env->startSection('content'); ?>
<a href="/event" class="button-return">Kembali</a>
<div class="form-container">
	<div class="title">Ubah Data Tamu</div>
<form method="post" action="<?php echo e('/event/'.$data->id); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PUT'); ?>
	<div class="universal-form">
	<div class="universal-input-box">
		<span class="detail">Agenda</span>
    	<input type="text"  name="agenda" id="agenda" value="<?php echo e($data->agenda); ?>">
  	</div>
</div>
<div class="button-submit">
		<input type="submit" value="Simpan">
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/event/edit.blade.php ENDPATH**/ ?>