<header>
    <h2 class="logo">Logo</h2>
        <nav class="navigation">
            
            <a href="/guestform" class="button-guest">Form</a>
            <a href="/session" class="button-login-popup">Login</a>
        </nav>
</header><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/layout/guest.blade.php ENDPATH**/ ?>