<!DOCTYPE html>
<html lang="en">
<head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/fonts/icomoon/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/css/owl.carousel.min.css')); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/css/bootstrap.min.css')); ?>">
    
    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/css/style.css')); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/layout/headerbase.blade.php ENDPATH**/ ?>