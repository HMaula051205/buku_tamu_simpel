
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
 <h1> Home  </h1>
    <h2> Selamat Datang <?php echo e($name); ?> Kamu Adalah <?php echo e($role); ?> </h2>
    <?php if($role == 'Admin'): ?>
          <a href="/admin"> Ke Halaman Admin</a>
    <?php elseif($role == 'Staff'): ?>
          <a href="/staff"> Ke Halaman gudang</a>
    <?php else: ?>
          <a> Lu Siapa Bang</a>
    <?php endif; ?>

    <table class="table table-striped">
    <tr>

    <th>   No       </th>
    <th>   Nama     </th>

    </tr>
    <?php $__currentLoopData = $buah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>

     <th> <?php echo e($loop->iteration); ?> </th> 
     <th> <li> <?php echo e($data); ?> </li> </th> 
    

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    <a style="color:#FBD605" href="/message">Ke Halaman Pesan</a>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara9_master\resources\views/home.blade.php ENDPATH**/ ?>