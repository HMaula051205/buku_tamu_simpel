

<?php $__env->startSection('content'); ?>
<div class="form-container">
    <div class="universal-form">
        <form method="post" action="/formbuilder" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
            <div class="universal-input-box">
                <span class="detail">Tanggal</span>
                <input type="date" name="date" id="date" value="<?php echo e(Session::get('date')); ?>">
            </div>
            <div class="universal-input-box">
                <span class="detail">Nama Agenda</label>
                <input type="text" placeholder="Masukkan nama tamu" name="agenda" id="agenda">
            </div>
        <div class="button-submit">
            <input type="submit" value="Simpan"></input>
        </div>
        <div id="fb-editor"></div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/formbuilder/create.blade.php ENDPATH**/ ?>