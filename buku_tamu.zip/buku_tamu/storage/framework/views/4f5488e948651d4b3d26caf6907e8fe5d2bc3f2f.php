<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>about</title>
</head>
<body>
    <h1> ini Adalah <?php echo e($id); ?> </h1>
    <p>=============================</p>
    <p>=============================</p>
    <p>=============================</p>
    <p>=============================</p>
</body>
</html><?php /**PATH C:\xampp1\htdocs\lara9_master\resources\views/product/about.blade.php ENDPATH**/ ?>