<html>
<head></head>
<body>
<h1>HI</h1>
<h2><?php echo e($name); ?></h2>
<h2><?php echo e($number); ?></h2>
</body>
</html><?php /**PATH F:\xampp.laravel\htdocs\lara9_master\resources\views/contact.blade.php ENDPATH**/ ?>