

<?php $__env->startSection('content'); ?>
<div class="form-container">
	<div class="title">Tambah Data Tamu</div>
		<form method="post" action="/event" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="universal-form">
				<div class="universal-input-box">
					<span class="detail">Agenda</span>
					<input type="text" name="agenda" id="agenda" value="<?php echo e(Session::get('agenda')); ?>">
				</div>
			</div>
			<div class="button-submit">
					<input type="submit" value="Simpan"></input>
			</div>	
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/event/create.blade.php ENDPATH**/ ?>