<div class="modal" data-id="<?php echo e($id); ?>">
    <div class="modal-box">
        <form action="" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <i><ion-icon name="alert-circle-sharp"></ion-icon></i>
        <h3>Apakah kamu yakin ingin menghapus data ini?</h3>
        <div class="button-modal">
            <button class="button-close" data-dismiss="modal">Batal</button>
            <button class="button-delete">Ya</button>
        </div>
    </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/extra/modal.blade.php ENDPATH**/ ?>