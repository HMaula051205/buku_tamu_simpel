<!DOCTYPE html>

<html lang="en">

<head>
	<meta charset="utf-8"/>

	<title>Add Guest</title>
</head>

<body>


</body>
</html><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/guest/add.blade.php ENDPATH**/ ?>