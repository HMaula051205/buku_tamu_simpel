
<?php $__env->startSection('title', 'class'); ?>

<?php $__env->startSection('content'); ?>

<h1> Ini Adalah Halaman Class</h1>
<p> Mamayukero</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\lara9_master\resources\views/classRoom.blade.php ENDPATH**/ ?>