

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Data Tamu'); ?>

<section>
    <div class="table-container">
        <form action="<?php echo e(url('/guest')); ?>" method="GET">
            <input type="text" name="query" placeholder="Cari data" value="<?php echo e(request('query')); ?>">
            <button type="submit">Cari</button>
        </form>
        <div class="sort-container">
            <label for="sort">Urutkan berdasarkan:</label>
            <select id="sort">
                <option value="date_asc">Tanggal (Terbaru ke Terlama)</option>
                <option value="date_desc">Tanggal (Terlama ke Terbaru)</option>
                <option value="name_asc">Nama (A-Z)</option>
                <option value="name_desc">Nama (Z-A)</option>
                <!-- Tambahkan opsi untuk kriteria pengurutan lain jika diperlukan -->
            </select>
            <button id="sort-button">Urutkan</button>
        </div>
        <table class="table-guest">
            <thead>
                <h2>Buku Tamu</h2>
                <tr>
                    <th><a href="/guest/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Nama</th>
                    <th>Instansi</th>
                    <th>Agenda</th>
                    <th>Keterangan</th>
                    <th colspan="2">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td data-label="Foto">
                <?php if($item->picture): ?>
                <img style="max-width:100px;" src="<?php echo e(url ('picture').'/'.$item->picture); ?>"/>
                <?php endif; ?>
                </td>
            <td data-label="No"><?php echo e($loop->iteration); ?></td>
            <td data-label="Tanggal"><?php echo e($item->date); ?></td>
            <td data-label="Nama"><?php echo e($item->name); ?></td>
            <td data-label="Instansi"><?php echo e($item->agency->agency_name); ?></td>
            <td data-label="Agenda"><?php echo e($item->agenda); ?></td>
            <td data-label="Keterangan"><?php echo e($item->information); ?></td>
            <td data-label="Ubah"><a class="button-edit" href='<?php echo e(url('/guest/'.$item->id.'/edit')); ?>'><ion-icon name="pencil-sharp"></ion-icon></a></td>
            <td data-label="Hapus"><button class="show-modal" type="button" data-id="<?php echo e($item->id); ?>"><ion-icon name="trash-sharp"></ion-icon></button></td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e('/guest/'.$item->id); ?>" method='post'>
        <?php echo $__env->make('extra/modal', ['id' => $item->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="hidden" name="_method" value="DELETE">
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/guest/index.blade.php ENDPATH**/ ?>