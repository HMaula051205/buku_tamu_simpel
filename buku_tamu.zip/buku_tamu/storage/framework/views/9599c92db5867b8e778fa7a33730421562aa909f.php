

<?php $__env->startSection('content'); ?>
<div class="form-container">
<div class="universal-form">
    <a href="/formbuilder" class="button-return">Kembali</a>
    <h1><?php echo e($data->name); ?></h1>
    <p>
        <b>No Id</b> <?php echo e($data->id); ?>

    </p>
    <p>
        <b>Tanggal</b> <?php echo e($data->date); ?>

    </p>
    <section>
        <div class="table-container">
            <form action="<?php echo e(url('/form-builder')); ?>" method="GET">
                <input type="text" name="query" placeholder="Cari berdasarkan nama atau instansi" value="<?php echo e(request('query')); ?>">
                <button type="submit">Cari</button>
            </form>
            <table class="table-guest">
                <thead>
                    <h2>Form Acara</h2>
                    <tr>
                        <th><a href="/formbuilder/{id}/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
                        <th>No</th>
                        <th>Nama</th>
                        <th colspan="3">Action</th>
                    </tr>
                </thead>
                
            </table>
        </div>
    </section>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/formbuilder/detail.blade.php ENDPATH**/ ?>