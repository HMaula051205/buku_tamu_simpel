
<?php $__env->startSection('title', 'Message'); ?>
<?php $__env->startSection('content'); ?>
<h1> Ini Halaman Pesan</h1>

<table class="table table-striped">
<tr>

<th>   No     </th>
<th>   Judul  </th>
<th>   Isi    </th>

</tr>

<?php $__currentLoopData = $messageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>

<th> <?php echo e($loop->iteration); ?> </th> 
<th><li> <?php echo e($p->judul); ?>    </li></th>
<th><li> <?php echo e($p->isi); ?>      </li></th>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara9_master\resources\views/message.blade.php ENDPATH**/ ?>