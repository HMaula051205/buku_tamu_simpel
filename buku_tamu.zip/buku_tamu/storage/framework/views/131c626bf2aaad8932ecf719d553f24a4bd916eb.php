<!DOCTYPE html>
<html lang="en">
<head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/fonts/icomoon/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/css/owl.carousel.min.css')); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/css/bootstrap.min.css')); ?>">
    
    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('import/assets1/css/style.css')); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" 
      rel="stylesheet" 
      integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" 
      crossorigin="anonymous">
</head>
<body>
    <script src="<?php echo e(asset('import/assets1/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('import/assets1/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('import/assets1/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('import/assets1/js/jquery.sticky.js')); ?>"></script>
    <script src="<?php echo e(asset('import/assets1/js/main.js')); ?>"></script>
    <div class="container py-5">
        <?php if(Auth::check()): ?>
        <?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php echo $__env->make('extra/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/layout/baseheader.blade.php ENDPATH**/ ?>