

<?php $__env->startSection('title', 'Student'); ?>


<?php $__env->startSection('content'); ?>
<h1> Ini Adalah Halaman Student</h1>
<p> mf pulled this out</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/about.blade.php ENDPATH**/ ?>