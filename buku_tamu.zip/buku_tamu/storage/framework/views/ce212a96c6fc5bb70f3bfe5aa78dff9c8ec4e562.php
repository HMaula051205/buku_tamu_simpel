
<?php $__env->startSection('title', 'Inventory'); ?>

<?php $__env->startSection('content'); ?>

<h1> Ini Adalah Halaman Inventory</h1> 
<div class="mb-3">
<a href="inventory_add"><button class="btn-success">Tambah</a>
</div>
<table class="table table-striped">
    <tr>

    <th>   No       </th>
    <th>   Nama Barang    </th>
    <th>   Jumlah   </th>
    <th>   Kondisi   </th>

    </tr>
    <?php $__currentLoopData = $inventoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>

     <th>    <?php echo e($loop->iteration); ?>    </th> 
     <th> <li> <?php echo e($data->nama_barang); ?> </li> </th> 
     <th> <li> <?php echo e($data->jumlah); ?> </li> </th> 
     <th> <li> <?php echo e($data->kondisi); ?> </li> </th> 

    

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/inventory.blade.php ENDPATH**/ ?>