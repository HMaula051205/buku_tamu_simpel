
<?php $__env->startSection('title', 'rofiq'); ?>

<?php $__env->startSection('content'); ?>

<legend> <h1> Ini Adalah Halaman Utama <br> </h1> </legend>
<h1> Website ini Didirikan Pada Tahun 6789<br> </h1>
 <h1>Untuk Mengenang Jasa Komputer <br> </h1>
<p>=====================================================================</p>
<p>=====================================================================</p>
<p>=====================================================================</p>
<p>=====================================================================</p>
<p>=====================================================================</p>
<p>=====================================================================</p>
<p>=====================================================================</p>


<a href ="https://www.youtube.com/watch?v=CEWKIluer84">
<button type="button" class="btn btn-primary btn-lg btn-block" >Tekan Jika Penasaran</button>
</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\lara9_master\resources\views/rofiq.blade.php ENDPATH**/ ?>