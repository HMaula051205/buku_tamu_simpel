

<?php $__env->startSection('content'); ?>
<div class="form-container">
	<div class="title">Tambah Data Instansi</div>
		<form method="post" action="/agency" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="universal-form">
				<div class="universal-input-box">
					<span class="detail">Nama Instansi</span>
					<input type="text" name="agency_name" id="agency_name" value="<?php echo e(old('agency_name')); ?>">
				</div>
				<div class="universal-input-box">
					<span class="detail">Logo</span>
					<input type="file" name="picture" id="picture" value="<?php echo e(Session::get('picture')); ?>">
				</div>
			</div>
			<div class="button-submit">
				<input type="submit" value="Simpan">
			</div>	
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/agency/create.blade.php ENDPATH**/ ?>