

<?php $__env->startSection('title', 'Tambah Data' | 'Add New'); ?>

<?php $__env->startSection('content'); ?>

<div class="mt-5 col-6 m-auto">
    <h1 style="color: teal">Tambah</h1>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<form action="tamu" method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="haritanggal">Hari/Tanggal</label>
        <input type="text" class= " form-control  " name="haritanggal" id="haritanggal">
    </div>
    <div class="mb-3">
        <label for="nama">Nama</label>
        <input type="text" class= " form-control  " name="nama" id="nama">
    </div>
    <div class="mb-3">
        <label for="instansi">Instansi</label>
        <input type="text" class="form-control" name="instansi" id="instansi">
    </div>
    <div class="mb-3">
        <label for="agenda">Agenda</label>
        <input type="text" class="form-control" name="agenda" id="agenda">
    </div>
    <div class="mb-3">
        <label for="keterangan">Keterangan</label>
        <input type="text" class="form-control" name="keterangan" id="keterangan">
    </div>
    <div class="mb-3">
            <button class="btn btn-success" type="submit">simpan</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/tamu-add.blade.php ENDPATH**/ ?>