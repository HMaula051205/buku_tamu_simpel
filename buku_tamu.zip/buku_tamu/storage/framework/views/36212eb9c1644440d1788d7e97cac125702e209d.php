

<?php $__env->startSection('content'); ?>
<a href="/guest/create" class="btn btn-primary btn-sm">Tambah data</a>
<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Instansi</th>
            <th>Agenda</th>
            <th>Keterangan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->agency); ?></td>
            <td><?php echo e($item->agenda); ?></td>
            <td><?php echo e($item->information); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views//guest/index.blade.php ENDPATH**/ ?>