
<?php $__env->startSection('title', 'class'); ?>

<?php $__env->startSection('content'); ?>

<h1> Ini Adalah Halaman Class</h1>

<table class="table table-striped">
    <tr>

    <th>   No       </th>
    <th>   Class     </th>

    </tr>
    <?php $__currentLoopData = $ClassList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>

     <th>    <?php echo e($loop->iteration); ?>    </th> 
     <th> <li> <?php echo e($data->name); ?> </li> </th> 
    

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\lara9_master\resources\views/ClassRoom.blade.php ENDPATH**/ ?>