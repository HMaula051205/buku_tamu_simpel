
<?php $__env->startSection('title', 'Harits'); ?>

<?php $__env->startSection('content'); ?>

<legend> <h1> Ini Adalah Halaman Utama <br> </h1> </legend>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara9_master\resources\views/harits.blade.php ENDPATH**/ ?>