

<?php $__env->startSection('content'); ?>
<section>
    <div class="table-container">
        <form action="<?php echo e(url('/formbuilder')); ?>" method="GET">
            <input type="text" name="query" placeholder="Cari form" value="<?php echo e(request('query')); ?>">
            <button type="submit">Cari</button>
        </form>
        <table class="table-guest">
            <thead>
                <h2>Form Acara</h2>
                <tr>
                    <th><a href="/formbuilder/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
                    <th>No</th>
                    <th>Nama</th>
                    <th colspan="3">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td data-label="Foto">
                <?php if($item->picture): ?>
                <img style="max-width:100px;" src="<?php echo e(url ('picture').'/'.$item->picture); ?>"/>
                <?php endif; ?>
                </td>
            <td data-label="No"><?php echo e($loop->iteration); ?></td>
            <td data-label="Agenda"><?php echo e($item->agenda); ?></td>
            <td data-label="Ubah"><a class="button-edit" href='<?php echo e(url('/formbuilder/'.$item->id.'/edit')); ?>'><ion-icon name="pencil-sharp"></ion-icon></a></td>
            <td data-label="Lihat"><a class="button-edit" href='<?php echo e(url('/formbuilder/'.$item->id)); ?>'><ion-icon name="search-sharp"></ion-icon></a></td>
            <td data-label="Hapus"><button class="show-modal"><ion-icon name="trash-sharp"></ion-icon></button></td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e('/formbuilder/'.$item->id); ?>" method='post'>
        <?php echo $__env->make('extra/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/formbuilder/index.blade.php ENDPATH**/ ?>