

<?php $__env->startSection('content'); ?>
<section>
		<div class="table-container">
            <table class="table-guest">
    <thead>
        <h2>Daftar Acara</h2>
        <tr>
            <th><a href="/event/create" class="button-create"><ion-icon name="add-sharp"></ion-icon></a></th>
            <th>No</th>
            <th>Agenda</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td data-label="No"><?php echo e($loop->iteration); ?></td>
            <td data-label="Agenda"><?php echo e($item->agenda); ?></td>
            <td data-label="Ubah"><a class="button-edit" href='<?php echo e(url('/event/'.$item->id.'/edit')); ?>'>Ubah</a></td>
            <td data-label="Detail"><a class="button-detail" href='<?php echo e(url('/event/detail/'.$item->id.'/')); ?>'>Detail</a></td>
            <td data-label="Hapus">
                <form action="<?php echo e('/event/'.$item->id); ?>" method='post'>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="show-modal" type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</table>
</div>
</section>
<?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buku_tamu\resources\views/event/index.blade.php ENDPATH**/ ?>