<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Guest;
use App\Models\Agency;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;

class GuestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = $request->input('query');
        $sort = $request->input('sort');

    $guestQuery = Guest::query()->with('agency');

    if ($query) {
        $guestQuery->whereHas('agency', function($queryBuilder) use ($query) {
            $queryBuilder->where('agency_name', 'like', '%' . $query . '%');
        })
        ->orWhere('name', 'like', '%' . $query . '%')
        ->orWhere('agenda', 'like', '%' . $query . '%')
        ->orWhere('date', 'like', '%' . $query . '%')
        ->orWhere('information', 'like', '%' . $query . '%');
    }
    

    switch ($sort) {
        case 'date_asc':
            $guestQuery->orderBy('date', 'asc');
            break;
        case 'date_desc':
            $guestQuery->orderBy('date', 'desc');
            break;
        case 'name_asc':
            $guestQuery->orderBy('name', 'asc');
            break;
        case 'name_desc':
            $guestQuery->orderBy('name', 'desc');
            break;
    }

    $guests = $guestQuery->paginate(5)->appends(['query' => $query, 'sort' => $sort]);

    return view('guest.index')->with('data', $guests);
}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $guest = Guest::get();
        $agency = Agency::get();
        return view ('guest/create', compact('agency','guest'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Session::flash('name', $request->name);
        Session::flash('agency_id', $request->agency_id);
        
        $request->validate([
            'date'=>'required',
            'name'=>'required',
            'agency_id'=>'required',
            'agenda'=>'nullable',
            'information'=>'nullable',
            'picture'=>'required|mimes:jpeg,jpg,png'
        ],[
            'date.required'=>'Harap isi kolom tanggal',
            'name.required'=>'Harap isi kolom nama tamu',
            'agency_id.required'=>'Harap isi kolom instansi',
            'picture.required'=>'Harap masukkan gambar',
            'picture.mimes'=>'Harap masukkan foto berekstensi jpeg, jpg, atau png'
        ]);

        $picture_file = $request->file('picture');
        $picture_extension = $picture_file->extension();
        $picture_name = date('ymdhis').".".$picture_extension;
        $picture_file->move(public_path('picture'), $picture_name);

        $guest = [
            'date' => $request->input('date'),
            'name' => $request->input('name'),
            'agency_id' => $request->input('agency_id'),
            'agenda' => $request->input('agenda'),
            'information' => $request->input('information'),
            'picture' => $picture_name
        ];
        Guest::create($guest);
        return redirect('guest')->with('success', 'Data berhasil dimasukkan');
    }

    public function show($id)
    {
        $guest = guest::where('id', $id)->first();
        return view ('guest/detail')->with('data', $guest);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $agency = Agency::get();
        $guest = Guest::with('agency')->find($id);
        return view ('guest/edit')->with([
            'data' => $guest,
            'agency' => $agency
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'date'=>'required',
            'name'=>'required',
            'agency_id'=>'required',
            'agenda'=>'nullable',
            'information'=>'nullable',
            'picture'=>'nullable|mimes:jpeg,jpg,png'
        ],[
            'date.required'=>'Harap isi kolom tanggal',
            'name.required'=>'Harap isi kolom nama tamu',
            'agency_id.required'=>'Harap isi kolom instansi',
            'picture.mimes'=>'Harap masukkan foto berekstensi jpeg, jpg, atau png'
        ]);

    $guest = Guest::findOrFail($id);
        $oldPicture = $guest->picture;
    
        if ($request->hasFile('picture')) {
            $picture_file = $request->file('picture');
            $picture_extension = $picture_file->getClientOriginalExtension();
            $picture_name = date('ymdhis') . "." . $picture_extension;
    
            $picture_file->move(public_path('picture'), $picture_name);
            File::delete(public_path('picture') . '/' . $oldPicture);
    
            $guest->picture = $picture_name;
        }

        $guest->date = $request->input('date');
        $guest->name = $request->input('name');
        $guest->agency_id = $request->input('agency_id');
        $guest->agenda = $request->input('agenda');
        $guest->information = $request->input('information');
        
        $guest->name = $request->input('name');
        $guest->save();
    
        return redirect('/guest')->with('success', 'Data berhasil diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $guest = Guest::where('id', $id)->first();
        File::delete(public_path('picture').'/'.$guest->picture);
        Guest::where('id', $id)->delete();
        return redirect ('/guest')->with('success', 'Data berhasil dihapus');
    }

}
