<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Guest;
use App\Models\Agency;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;

class GuestFormController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $guest = Guest::get();
        $agency = Agency::get();
        return view ('guestform');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $picture_file = $request->file('picture');
        $picture_extension = $picture_file->extension();
        $picture_name = date('ymdhis').".".$picture_extension;
        $picture_file->move(public_path('picture'), $picture_name);

        $agency = Agency::create([
            'agency_name' => $request->input('agency_name'),
        ]);
        
        Guest::create([
            'date' => $request->input('date'),
            'name' => $request->input('name'),
            'agency_id' => $agency->id,
            'agenda' => $request->input('agenda'),
            'information' => $request->input('information'),
            'picture' => $picture_name
        ]);

        return redirect('guestform')->with('success', 'Data berhasil dimasukkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
