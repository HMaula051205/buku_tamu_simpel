<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Agency;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;

class AgencyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = $request->input('query');

        if($query){
            $agency = Agency::where('agency_name', 'like', '%' . $query . '%')
                            ->paginate(5)
                            ->appends(['query' => $query]);
        } else {
            $agency = Agency::orderBy('agency_name', 'asc')->paginate(5);
        }
        return view ('agency/index')->with('data', $agency);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view ('agency/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {      
        $request->validate([
            'agency_name'=>'required',
            'picture'=>'required|mimes:jpeg,jpg,png',
        ],[
            'agency_name.required'=>'Harap isi kolom nama instansi',
            'picture.required'=>'Harap masukkan gambar logo',
            'picture.mimes'=>'Harap masukkan gambar logo dengan ekstensi jpeg, jpg, atau png'
        ]);

        $picture_file = $request->file('picture');
        $picture_extension = $picture_file->extension();
        $picture_name = date('ymdhis').".".$picture_extension;
        $picture_file->move(public_path('picture'), $picture_name);

        $agency = [
            'agency_name' => $request->input('agency_name'),
            'picture' => $picture_name
        ];

        Agency::create($agency);
        return redirect('agency')->with('success', 'Data berhasil dimasukkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $agency = Agency::where('id', $id)->first();
        return view ('agency/detail')->with('data', $agency);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $agency = Agency::where('id', $id)->first();
        return view ('agency/edit')->with('data', $agency);//
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'agency_name' => 'required',
            'picture' => 'nullable|mimes:jpeg,jpg,png'
        ], [
            'agency_name.required' => 'Harap isi kolom nama instansi',
            'picture.mimes' => 'Harap masukkan foto dengan ekstensi jpeg, jpg, atau png'
        ]);
    
        $agency = Agency::findOrFail($id);
        $oldPicture = $agency->picture;
    
        if ($request->hasFile('picture')) {
            $picture_file = $request->file('picture');
            $picture_extension = $picture_file->getClientOriginalExtension();
            $picture_name = date('ymdhis') . "." . $picture_extension;
    
            $picture_file->move(public_path('picture'), $picture_name);
            File::delete(public_path('picture') . '/' . $oldPicture);
    
            $agency->picture = $picture_name;
        }
    
        $agency->agency_name = $request->input('agency_name');
        $agency->save();
    
        return redirect('/agency')->with('success', 'Data berhasil diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $agency = Agency::where('id', $id)->first();
        File::delete(public_path('picture').'/'.$agency->picture);
        Agency::where('id', $id)->delete();
        return redirect ('/agency')->with('success', 'Data berhasil dihapus');
    }
}
