<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;

class SessionController extends Controller
{
    public function index()
    {
        return view('session/index');
    }

    public function login(Request $request)
    {
        Session::flash('email', $request->email);
        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ],[
            'email.required' => 'Harap mengisi email anda',
            'password.required' => 'Harap mengisi password anda'
        ]);

        $logininfo = [
            'email' => $request->email,
            'password' => $request->password
        ];

        if(Auth::attempt($logininfo)){
            return redirect('guest')->with('success', 'Berhasil Login');
        } else {
            return redirect('session')->withErrors('Email dan Password tidak valid');
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect ('session')->with('success', 'Berhasil Logout');
    }
    
    public function register()
    {
        return view('session');
    }

    public function create(Request $request)
    {
        Session::flash('email', $request->email);
        Session::flash('name', $request->name);
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6'
        ],[
            'name.required' => 'Harap mengisi username anda',
            'email.required' => 'Harap mengisi email anda',
            'email.email' => 'Harap masukkan email yang valid',
            'email.unique' => 'Email sudah digunakan',
            'password.required' => 'Harap mengisi password anda',
            'password.min' => 'Password harus berisi dari 8 karakter atau lebih'
        ]);

        $user = [
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ];

        User::create($user);

        $logininfo = [
            'email' => $request->email,
            'password' => $request->password
        ];

        if(Auth::attempt($logininfo)){
            return redirect('guest')->with('success', Auth::user()->name.' Berhasil Register');
        } else {
            return redirect('session')->withErrors('Email dan Password tidak valid');
        }
    }
}
