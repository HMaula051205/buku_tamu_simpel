<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Agency;

class guest extends Model
{
    use HasFactory;

    protected $table ="guests";
    protected $fillable = ['date','name','agency_id', 'agenda', 'information', 'picture'];

    public function agency()
    {
        return $this->belongsTo('App\Models\Agency');
    }
    

}
