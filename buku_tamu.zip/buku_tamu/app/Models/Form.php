<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Form extends Model
{
    use HasFactory;

    protected $table ="forms";
    protected $fillable = ['date', 'name'];

    public function formbuilders(): BelongsTo
    {
        return $this->belongsTo(formbuilders::class, 'foreiign_key', 'other_key');
    }
}
