<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Guest;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Agency extends Model
{
    use HasFactory;
    protected $table ="agencies";
    protected $fillable = ['agency_name', 'picture'];

    public function guest(): HasMany
    {
        return $this->hasMany(Guest::class);
    }

    public function hasGuest(): bool
    {
        return $this->guest()->exists();
    }
}
