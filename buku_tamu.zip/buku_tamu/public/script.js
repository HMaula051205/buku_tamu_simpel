const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const modal = document.querySelector('.modal');
const overlay = document.querySelector('.overlay');
const showModal = document.querySelectorAll('.show-modal');
const buttonClose = document.querySelector('.button-close');
const dropdown = document.querySelector('.dropdown');
const buttonDelete = document.querySelectorAll('.button-delete');
const buttonPopup= document.querySelector('.button-login-popup');
const iconClose = document.querySelector('.icon-close')
// const guestForm = document.querySelector('.guestform')
// const buttonGuest = document.querySelector('.button-guest')

registerLink && registerLink.addEventListener('click', ()=> {
    wrapper.classList.add('active');
});

loginLink && loginLink.addEventListener('click', ()=> {
    wrapper.classList.remove('active');
});

showModal && showModal.forEach(function(button) {
    button.addEventListener('click', (event)=> {
        modal.classList.add('active'); // Mencegah event menyebar
        // Tambahkan logika lain jika diperlukan
    });
}); 

buttonClose && buttonClose.addEventListener('click', (event)=> {
    event.preventDefault();
    modal.classList.remove('active');
})

overlay && overlay.addEventListener('click', ()=> {
    modal.classList.remove('active');
})

dropdown && dropdown.addEventListener('click', ()=> {
    dropdown.classList.add('active');
})

buttonDelete && buttonDelete.forEach(function(button) {
    button.addEventListener('click', (event)=> {
        event.stopPropagation(); // Mencegah event menyebar
        // Tambahkan logika lain jika diperlukan
    });
});

buttonPopup && buttonPopup.addEventListener('click', ()=> {
    wrapper.classList.add('active-popup');
});

iconClose && iconClose.addEventListener('click', ()=> {
    wrapper.classList.remove('active-popup');
});

// buttonGuest && buttonGuest.addEventListener('click', ()=> {
//     guestForm.classList.add('active-popup');
// });


