const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const modal = document.querySelectorAll('.modal');
const overlay = document.querySelector('.overlay');
const showModal = document.querySelectorAll('.show-modal');
const buttonClose = document.querySelectorAll('.button-close');
const dropdown = document.querySelector('.dropdown');
const buttonDelete = document.querySelectorAll('.button-delete');
const buttonPopup= document.querySelector('.button-login-popup');
const iconClose = document.querySelector('.icon-close')
const sortButton = document.getElementById('sort-button');

registerLink && registerLink.addEventListener('click', ()=> {
    wrapper.classList.add('active');
});

loginLink && loginLink.addEventListener('click', ()=> {
    wrapper.classList.remove('active');
});

showModal && showModal.forEach(function(button) {
    button.addEventListener('click', (event)=> {
        const id = button.getAttribute('data-id');
        const modal = document.querySelector(`.modal[data-id="${id}"]`);
        modal.classList.add('active'); 
    });
}); 

buttonClose && buttonClose.forEach(function(button) {
    button.addEventListener('click', (event)=> {
        event.preventDefault();
        const modal = button.closest('.modal');
        modal.classList.remove('active');
    });
})

overlay && overlay.addEventListener('click', ()=> {
    modal.classList.remove('active');
})

dropdown && dropdown.addEventListener('click', ()=> {
    dropdown.classList.add('active');
})

buttonDelete && buttonDelete.forEach(function(button) {
    button.addEventListener('click', (event)=> {
        event.stopPropagation();
    });
});

buttonPopup && buttonPopup.addEventListener('click', ()=> {
    wrapper.classList.add('active-popup');
});

iconClose && iconClose.addEventListener('click', ()=> {
    wrapper.classList.remove('active-popup');
});

sortButton.addEventListener('click', () => {
    const sortCriteria = document.getElementById('sort').value;
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('sort', sortCriteria);
    window.location.search = urlParams.toString();
});


