<?php

$guest = [
    "name" => "Harits Maula",
    "agency" => "SMK ICB CT",
    "agenda" => "Praktik Ujikom",
    "information" => ""
];

$encoded_data = json_encode($guest);

file_put_contents('data.json', $encoded_data);

?>